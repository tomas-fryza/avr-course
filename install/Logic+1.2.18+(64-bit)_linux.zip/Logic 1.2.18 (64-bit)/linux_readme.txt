Hello, and welcome to Logic on Linux!

You should be able to double click on the 'Logic' file in this folder, and launch the software.

There is no installer.  You can place this folder wherever you like.  For example, you might want to move it to your home folder, and make a shortcut to �Logic' on your desktop or dock.   Keep in mind that wherever you put it, it needs to have write permissions, and it needs to keep the same folder structure � i.e. the application expects its various files and folders to maintain their relative positions.

Before using the software with the Logic or Logic16 hardware, you'll need to give the application permission to access the device (otherwise you'll have to launch the application with sudo).  To do this, unplug any attached Logic/Logic16 device, and then run the script in the Driver folder from the command line.  After that you should be good to go.

As always, questions, issues and feedback are always welcome at support@saleae.com.  Happy debugging!
Branch: master
Commit Id: baf39a68b7bc0e642fa7a233f310663c47bcf5e3
